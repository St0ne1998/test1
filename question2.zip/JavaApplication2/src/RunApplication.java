// RULE: The Interface (ISales)
interface ISales {
    String GetShoeBrand();
    int GetBrandSales();
}

// RULE: The SalesModel Class to hold data
class SalesModel {
    public String ShoeBrand;
    public int BrandSales;

    public SalesModel(String brand, int sales) {
        this.ShoeBrand = brand;
        this.BrandSales = sales;
    }
}

// RULE: The Abstract Class (Sales) implementing ISales
abstract class Sales implements ISales {
    protected String shoeBrand;
    protected int brandSales;

    // RULE: Constructor accepting SalesModel as parameter
    public Sales(SalesModel model) {
        this.shoeBrand = model.ShoeBrand;
        this.brandSales = model.BrandSales;
    }

    @Override
    public String GetShoeBrand() { return shoeBrand; }

    @Override
    public int GetBrandSales() { return brandSales; }
}

// RULE: Subclass (PrintSales) extending the Abstract Class
class PrintSales extends Sales {
    public PrintSales(SalesModel model) {
        super(model);
    }

    // RULE: Print() method to match sample output
    public void Print() {
        System.out.println("***************************");
        System.out.println("SHOE SALES PRINTOUT");
        System.out.println("***************************");
        System.out.println("SHOE BRAND: " + GetShoeBrand());
        System.out.println("SHOE BRAND SALES: " + GetBrandSales());
        System.out.println("***************************");
    }
}

// RULE: RunApplication class to execute
public class RunApplication {
    public static void main(String[] args) {
        // RULE: Populate SalesModel
        SalesModel data = new SalesModel("NIKE", 100);

        // RULE: Instantiate PrintSales using SalesModel
        PrintSales report = new PrintSales(data);

        // Execute
        report.Print();
    }
}